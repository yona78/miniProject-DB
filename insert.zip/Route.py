import random

a=['burden','traveling']
res="INSERT INTO `Route`(`route_id`, `origin_station_id`, `destination_station_id`, `distance`, `type_route`) VALUES"
for i in range (1000):
    res += '('
    res += str(i)
    res += ","
    res += str(random.randint(0,999))
    res += ","
    res += str(random.randint(0,999))
    res += ","
    res += str(random.randint(0,999))
    res += ","
    res += "'"
    res += str(a[random.randint(0,1)])
    res += "'"
    res += ")"
    if (i + 1 < 1000):
        res += ","

    #(i, random.randint(0,999), random.randint(0,999),random.randint(0,999), a[random.randint(0,1)]);
res+=";"
print(res)
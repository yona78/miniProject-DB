import random

a=['John', 'Emily', 'David', 'Sarah', 'Mark', 'Jennifer', 'Michael', 'Katherine', 'Andrew', 'Jessica', 'Christopher', 'Lauren', 'Matthew', 'Rachel', 'Anthony', 'Stephanie', 'Robert', 'Melissa', 'Brian', 'Amanda', 'William', 'Ashley', 'Jonathan', 'Elizabeth', 'Nicholas', 'Taylor', 'Kevin', 'Victoria', 'Brandon', 'Olivia', 'Jacob', 'Madison', 'Eric', 'Megan', 'Steven', 'Samantha', 'Thomas', 'Danielle', 'Tyler', 'Nicole', 'Adam', 'Gabrielle', 'Benjamin', 'Hannah', 'Patrick', 'Chloe', 'Timothy', 'Alyssa', 'Richard', 'Alexandra', 'Philip', 'Natalie', 'Charles', 'Mackenzie', 'Jeffrey', 'Morgan', 'Ryan', 'Kayla', 'Scott', 'Julia', 'Donald', 'Grace', 'Joshua', 'Amelia', 'Daniel', 'Sydney', 'Joseph', 'Brianna', 'Peter', 'Jasmine', 'George', 'Isabella', 'Edward', 'Kaitlyn', 'Francis', 'Faith', 'Martin', 'Caroline', 'Derek', 'Sara', 'Victor', 'Paige', 'Raymond', 'Emma', 'Arthur', 'Avery', 'Louis', 'Lily', 'Walter', 'Evelyn', 'Gregory', 'Aubrey', 'Henry', 'Brooke', 'Stephen', 'Lila', 'Harold', 'Hailey', 'Gerald', 'Claire', 'Kenneth', 'Allison', 'Roger', 'Sophie', 'Lawrence', 'Leah', 'Norman', 'Sadie', 'Samuel', 'Nora', 'Albert', 'Ellie', 'Frank', 'Madeline', 'Ralph', 'Ariana', 'Wayne', 'Riley', 'Keith', 'Bella', 'Howard', 'Peyton', 'Eugene', 'Skylar', 'Roy', 'Aaliyah', 'Terry', 'Gabriella', 'Roger', 'Jocelyn', 'Frederick', 'Angelina', 'Leonard', 'Makayla', 'Oscar', 'Kennedy', 'Clarence', 'Adriana', 'Lester', 'Mia', 'Glenn', 'Isabelle', 'Jared', 'Maya', 'Joel', 'Elise', 'Max', 'Violet', 'Levi', 'Anna', 'Trevor', 'Gianna', 'Nathan', 'Jordyn', 'Bradley', 'Piper', 'Landon', 'Haley', 'Miles', 'Kylie', 'Aaron', 'Londyn', 'Cameron', 'Layla', 'Dennis', 'Makenna', 'Isaac', 'Aria', 'Calvin', 'Mariah', 'Alex', 'Rylee', 'Carl', 'Alexis', 'Roland', 'Audrey', 'Eddie', 'Isabel', 'Gordon', 'Mckenzie', 'Isaiah', 'Adalyn', 'Harry', 'Delaney', 'Jerome', 'Julianna',
   'Ronald']
b=['2023-01-01', '2023-01-01', '2023-01-02', '2023-01-02', '2023-01-03', '2023-01-03', '2023-01-04', '2023-01-04', '2023-01-05', '2023-01-05', '2023-01-06', '2023-01-06', '2023-01-07', '2023-01-07', '2023-01-08', '2023-01-08', '2023-01-09', '2023-01-09', '2023-01-10', '2023-01-10', '2023-01-11', '2023-01-11', '2023-01-12', '2023-01-12', '2023-01-13', '2023-01-13', '2023-01-14', '2023-01-14', '2023-01-15', '2023-01-15', '2023-01-16', '2023-01-16', '2023-01-17', '2023-01-17', '2023-01-18', '2023-01-18', '2023-01-19', '2023-01-19', '2023-01-20', '2023-01-20', '2023-01-21', '2023-01-21', '2023-01-22', '2023-01-22', '2023-01-23', '2023-01-23', '2023-01-24', '2023-01-24', '2023-01-25', '2023-01-25', '2023-01-26', '2023-01-26', '2023-01-27', '2023-01-27', '2023-01-28', '2023-01-28', '2023-01-29', '2023-01-29', '2023-01-30', '2023-01-30', '2023-01-31', '2023-01-31', '2023-02-01', '2023-02-01', '2023-02-02', '2023-02-02', '2023-02-03', '2023-02-03', '2023-02-04', '2023-02-04', '2023-02-05', '2023-02-05', '2023-02-06', '2023-02-06', '2023-02-07', '2023-02-07', '2023-02-08', '2023-02-08', '2023-02-09', '2023-02-09', '2023-02-10', '2023-02-10', '2023-02-11', '2023-02-11', '2023-02-12', '2023-02-12', '2023-02-13', '2023-02-13', '2023-02-14', '2023-02-14', '2023-02-15', '2023-02-15', '2023-02-16',
   '2023-02-16']

res="INSERT INTO `Ticket`(`ticket_id`, `train_id`, `passenger_name`, `departure_date`, `seat_number`, `fare_amount`, `payment_id`) VALUES"

for i in range (1000):
    res += '('
    res += str(i)
    res += ","
    res += str(random.randint(0, 999))
    res += ","
    res += "'"
    res += str(a[random.randint(0, len(a) - 1)])
    res += "'"
    res += ","
    res += "'"
    res += str(b[random.randint(0, len(b) - 1)])
    res += "'"
    res += ","
    res += str(random.randint(0, 500))
    res += ","
    res += str(random.randint(50,3000))
    res += ","
    res += str(random.randint(0,999))
    res += ")"
    if (i + 1 < 1000):
        res += ","

    #(i, random.randint(0,999),a[random.randint(0,len(a)-1)],b[random.randint(0,len(b)-1)], random.randint(0,500),random.randint(50,3000),random.randint(0,999) );

res+=";"
print(res)
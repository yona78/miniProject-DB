a=['Grand Central', 'Kings Cross', 'Penn Station', 'Gare du Nord', 'Shinjuku', 'Union Station', 'Chhatrapati Shivaji Terminus', 'Gare de Lyon', 'St Pancras International', 'Gare Saint-Lazare', 'Stazione di Roma Termini', 'Hauptbahnhof', 'Beijing Railway Station', 'Victoria Station', 'Gare Montparnasse', 'Zurich Hauptbahnhof', 'Gare de lEst', 'Berlin Hauptbahnhof', 'Tokyo Station', 'Liverpool Street', 'Gare dAusterlitz', 'Gare de Bordeaux-Saint-Jean', 'Stazione Centrale di Milano', 'Seoul Station', 'Santa Lucia', 'Amsterdam Centraal', 'Frankfurt Hauptbahnhof', 'Gare de Marseille-Saint-Charles', 'Charing Cross', 'Barcelona Sants', 'Stazione di Napoli Centrale', 'Gare de Rennes', 'New Street', 'Warszawa Centralna', 'Gare de Lille Europe', 'Wuhan Railway Station', 'Kings Lynn', 'Gare de Strasbourg', 'Gare de Nantes', 'Gare de Rouen-Rive-Droite', 'Gare de Caen', 'Gare de Brest', 'Gare de Limoges-Bénédictins', 'Gare de Dijon-Ville', 'Gare de Poitiers', 'Gare de Nancy-Ville', 'Gare de Rodez', 'Gare de Clermont-Ferrand', 'Gare de Pau', 'Gare de Niort', 'Gare de La Rochelle-Ville', 'Gare de Bourges', 'Gare de Toulouse-Matabiau', 'Gare de Lyon-Part-Dieu', 'Gare de Tours', 'Gare de Valenciennes', 'Gare de Lorient', 'Gare de Montauban-Ville-Bourbon', 'Gare de Rennes-Saint-Jacques', 'Gare de Montpellier-Saint-Roch', 'Gare de Grenoble', 'Gare de Nîmes', 'Gare de Besançon-Viotte', 'Gare de Bayonne', 'Gare de Nice-Ville', 'Gare de Lille-Flandres', 'Gare de Saint-Brieuc', 'Gare de Vannes', 'Gare de Metz-Ville', 'Gare de Le Mans', 'Gare de Tours-Saint-Pierre-des-Corps', 'Gare de Strasbourg-Ville', 'Gare de Périgueux', 'Gare de Saint-Malo', 'Gare de Saint-Nazaire', 'Gare de Laval', 'Gare de Quimper', 'Gare de Tarbes', 'Gare de Béziers', 'Gare de Troyes', 'Gare de Toulon', 'Gare de Mont-de-Marsan', 'Gare de Mulhouse', 'Gare de Angoulême', 'Gare de La Baule-Escoublac', 'Gare de Saintes', 'Gare de Angers-Saint-Laud', 'Gare de Auxerre-Saint-Gervais', 'Gare de Lausanne', 'Gare de Tours-Saint-Pierre-des-Corps',
   'Gare de Perpignan', 'Gare de Roubaix', 'Gare de Carcassonne', 'Gare de La Roche-sur-Yon']
b=['New York', 'London', 'Paris', 'Tokyo', 'Los Angeles', 'Berlin', 'Sydney', 'Beijing', 'Moscow', 'Toronto', 'Madrid', 'Rome', 'Rio de Janeiro', 'Istanbul', 'Seoul', 'Shanghai', 'Mumbai', 'Buenos Aires', 'San Francisco', 'Amsterdam', 'Mexico City', 'Dubai', 'Singapore', 'Hong Kong', 'Barcelona', 'Vienna', 'Chicago', 'Cape Town', 'San Diego', 'Stockholm', 'Athens', 'Miami', 'Montreal', 'Brussels', 'Prague', 'Oslo', 'Boston', 'Washington D.C.', 'Kuala Lumpur', 'Zurich', 'Dublin', 'Vancouver', 'Copenhagen', 'Munich', 'Helsinki', 'Lisbon', 'Manila',
   'Edinburgh', 'Budapest']
c=['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine',
   'Maryland']
d=['Canada', 'Mexico', 'Brazil', 'Argentina', 'Peru', 'Chile', 'Colombia', 'United Kingdom', 'France', 'Germany', 'Italy', 'Spain', 'Netherlands', 'Sweden', 'Norway', 'Finland', 'Denmark', 'Russia', 'China', 'Japan', 'South Korea', 'India', 'Pakistan', 'Australia', 'New Zealand', 'Indonesia', 'Thailand', 'Philippines', 'Vietnam', 'Malaysia', 'Singapore', 'Cambodia', 'Myanmar', 'South Africa', 'Egypt', 'Nigeria', 'Kenya', 'Morocco', 'Tunisia', 'Algeria', 'Ghana', 'Ethiopia', 'Saudi Arabia', 'Turkey', 'Iran', 'Israel', 'United Arab Emirates',
   'Qatar','United States']
e=['burden','traveling']

n=1000
import random
res="INSERT INTO `Station` (`station_id`, `station_name`, `city`, `state`, `country`, `establishment`, `type_station`) VALUES"
for i in range (n):
    res+= '('
    res+=str(i)
    res+=","
    res += "'"
    res +=str(a[random.randint(0,len(a)-1)])[0:20]
    res += "'"
    res +=","
    res += "'"
    res +=str(b[random.randint(0,len(b)-1)])
    res += "'"
    res +=","
    res += "'"
    res +=str(c[random.randint(0,len(c)-1)])
    res += "'"
    res +=","
    res += "'"
    res +=str(d[random.randint(0,len(d)-1)])
    res += "'"
    res +=","
    res +=str(random.randint(1700,2021))
    res +=","
    res += "'"
    res +=str(e[random.randint(0,1)])
    res += "'"
    res+=")"
    if(i+1<n):
        res+=","
    #(i, a[random.randint(0,len(a)-1)],b[random.randint(0,len(b)-1)], c[random.randint(0,len(c)-1)], d[random.randint(0,len(d)-1)], random.randint(1700,2023), e[random.randint(0,1)]);
res+=";"
print(res)
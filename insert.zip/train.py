import random

a=['Emily', 'Sophia', 'Emma', 'Olivia', 'Ava', 'Isabella', 'Mia', 'Charlotte', 'Amelia', 'Harper', 'Evelyn', 'Abigail', 'Luna', 'Camila', 'Chloe', 'Layla', 'Zoey', 'Avery', 'Riley', 'Ella', 'Elizabeth', 'Scarlett', 'Grace', 'Victoria', 'Aria', 'Penelope', 'Hazel', 'Nora', 'Nova', 'Eleanor', 'Addison', 'Aaliyah', 'Audrey', 'Audrina', 'Aubrey', 'Aurora', 'Autumn', 'Adalynn', 'Adeline', 'Adrianna', 'Alessandra', 'Alexandra', 'Alexandria', 'Alexia', 'Alexis', 'Aliyah', 'Alivia', 'Allison', 'Alondra', 'Alyssa', 'Amanda', 'Amara', 'Amina', 'Amy', 'Anastasia', 'Andrea', 'Angel', 'Angela', 'Angelica', 'Aniyah', 'Anna', 'Annabelle', 'Annalise', 'Anne', 'Annie', 'Ariana', 'Arianna', 'Ariel', 'Armani', 'Arya', 'Athena', 'Aubree', 'Aubrie', 'Audra', 'August', 'Aurelia', 'Aurora', 'Avaeh', 'Avalyn', 'Aviana', 'Ayla', 'Azalea', 'Bailey', 'Bella', 'Belle', 'Bentley', 'Bianca', 'Blake', 'Blakely', 'Bonnie', 'Braelynn', 'Brianna', 'Bridget', 'Brielle', 'Brinley', 'Bristol', 'Brittany', 'Brooke', 'Brooklyn', 'Brylee', 'Brynlee', 'Cadence', 'Caitlin', 'Cali', 'Callie', 'Camille', 'Candace', 'Cara', 'Carina', 'Carissa', 'Carla', 'Carly', 'Carmen', 'Carol', 'Caroline', 'Carolyn', 'Casey', 'Cassandra', 'Cassidy', 'Catalina', 'Catherine', 'Caylee', 'Cecilia', 'Celeste', 'Celia', 'Chanel', 'Charlee', 'Charleigh', 'Charley', 'Charlie', 'Charlize', 'Charmaine', 'Chelsea', 'Cheyenne', 'Chloe', 'Christina', 'Christine', 'Cindy', 'Clara', 'Clarissa', 'Claudia', 'Clementine', 'Colette', 'Collins', 'Cora', 'Corinne', 'Crystal', 'Daisy', 'Dakota', 'Dana', 'Daniela', 'Daniella', 'Danielle', 'Danika', 'Danna', 'Daphne', 'Darlene', 'Davina', 'Dayana', 'Deanna', 'Deborah', 'Delaney', 'Delilah', 'Denise', 'Desiree', 'Destiny', 'Diana', 'Diane', 'Dior', 'Dixie', 'Dolly', 'Dominique', 'Donna', 'Dorothy', 'Dream', 'Dulce',
   'Ebony']
b=[]
for i in range(1000):
    d=""
    d=d+"'"+str(random.randint(0,23))+':'+str(random.randint(0,59))+':'+str(random.randint(0,59))+"'"
    b.append(d)

c=['Alfa Romeo 4C', 'Acura NSX', 'Aston Martin DBS Superleggera', 'Audi R8', 'BMW M4', 'Bentley Continental GT', 'Bugatti Chiron', 'Buick Cascada', 'Cadillac CTS-V', 'Chevrolet Camaro', 'Chrysler 300', 'Dodge Challenger', 'Ferrari 488 GTB', 'Fiat 500', 'Ford Mustang', 'Genesis G70', 'GMC Sierra', 'Honda Civic', 'Hyundai Elantra', 'Infiniti Q50', 'Jaguar F-Type', 'Jeep Wrangler', 'Kia Stinger', 'Lamborghini Huracan', 'Land Rover Range Rover', 'Lexus LS', 'Lincoln Navigator', 'Lotus Evora', 'Maserati GranTurismo', 'Mazda MX-5 Miata', 'McLaren 720S', 'Mercedes-Benz S-Class', 'Mini Cooper', 'Mitsubishi Lancer Evolution', 'Nissan GT-R', 'Porsche 911', 'Rolls-Royce Phantom', 'Subaru WRX STI', 'Tesla Model S', 'Toyota Supra', 'Volkswagen Golf', 'Volvo S90', 'Acura TLX', 'Alfa Romeo Giulia', 'Aston Martin Vantage', 'Audi RS7', 'BMW 8 Series', 'Bentley Bentayga', 'Bugatti Veyron', 'Buick Enclave', 'Cadillac Escalade', 'Chevrolet Corvette', 'Chrysler Pacifica', 'Dodge Charger', 'Ferrari 812 Superfast', 'Fiat 124 Spider', 'Ford F-150', 'Genesis G90', 'GMC Yukon', 'Honda Accord', 'Hyundai Sonata', 'Infiniti QX80', 'Jaguar XE', 'Jeep Grand Cherokee', 'Kia Optima', 'Lamborghini Aventador', 'Land Rover Defender', 'Lexus ES', 'Lincoln Continental', 'Lotus Elise', 'Maserati Quattroporte', 'Mazda CX-5', 'McLaren 570S', 'Mercedes-Benz AMG GT', 'Mini Countryman', 'Mitsubishi Mirage', 'Nissan Altima', 'Porsche Panamera', 'Rolls-Royce Ghost', 'Subaru Outback', 'Tesla Model X', 'Toyota Camry', 'Volkswagen Jetta', 'Volvo XC90', 'Acura RLX', 'Alfa Romeo Stelvio', 'Aston Martin Rapide', 'Audi A7', 'BMW X7', 'Bentley Mulsanne', 'Buick Regal', 'Cadillac ATS', 'Chevrolet Impala', 'Chrysler 200', 'Dodge Journey', 'Ferrari Portofino', 'Fiat 500X', 'Ford EcoSport', 'Genesis G80', 'GMC Canyon', 'Honda Clarity', 'Hyundai Accent', 'Infiniti QX50', 'Jaguar XF', 'Jeep Cherokee', 'Kia Forte', 'Lamborghini Urus', 'Land Rover Range Rover Sport', 'Lexus GX', 'Lincoln MKC', 'Lotus Exige', 'Maserati Levante', 'Mazda CX-9', 'McLaren 675LT', 'Mercedes-Benz E-Class', 'Mini Clubman', 'Mitsubishi Outlander', 'Nissan Leaf',
   'Porsche Cayenne']

res="INSERT INTO `Train`(`train_id`, `train_name`, `route_id`, `departure_time`, `arrival_time`, `type_train`) VALUES"

for i in range (1000):
    res += '('
    res += str(i)
    res += ","
    res += "'"
    res += str(a[random.randint(0, len(a) - 1)])
    res += "'"
    res += ","
    res += str(random.randint(0, 999))
    res += ","
    res += str(b[random.randint(0, len(b) - 1)])
    res += ","
    res += str(b[random.randint(0, len(b) - 1)])
    res += ","
    res += "'"
    res += str(c[random.randint(0, len(c) - 1)])[0:20]
    res += "'"
    res += ")"
    if (i + 1 < 1000):
        res += ","

    #(i, a[random.randint(0,len(a)-1)],random.randint(0,999),b[random.randint(0,len(b)-1)],b[random.randint(0,len(b)-1)],c[random.randint(0,len(c)-1)] );

res+=";"
print(res)
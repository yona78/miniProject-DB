-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 19, 2023 at 01:10 PM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id20370336_tickets`
--

-- --------------------------------------------------------

--
-- Table structure for table `Train`
--

CREATE TABLE `Train` (
  `train_id` int(8) NOT NULL,
  `train_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `route_id` int(8) NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `type_train` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Train`
--

INSERT INTO `Train` (`train_name`, `num_tickets`) VALUES
('Aaliyah', 4),
('Abigail', 9),
('Adalynn', 18),
('Addison', 4),
('Adeline', 3),
('Adrianna', 1),
('Alessandra', 4),
('Alexandra', 4),
('Alexandria', 3),
('Alexia', 8),
('Alexis', 13),
('Alivia', 5),
('Aliyah', 7),
('Allison', 11),
('Alondra', 5),
('Alyssa', 2),
('Amanda', 12),
('Amara', 6),
('Amelia', 6),
('Amina', 2),
('Amy', 3),
('ana', 3),
('Anastasia', 1),
('Andrea', 3),
('Angel', 4),
('Angela', 9),
('Angelica', 3),
('Aniyah', 4),
('Anna', 1),
('Annabelle', 4),
('Annalise', 4),
('Anne', 5),
('Annie', 9),
('Aria', 2),
('Ariana', 3),
('Arianna', 9),
('Ariel', 8),
('Armani', 6),
('Arya', 8),
('Athena', 14),
('Aubree', 3),
('Aubrey', 8),
('Aubrie', 12),
('Audra', 15),
('Audrey', 4),
('Audrina', 5),
('August', 3),
('Aurelia', 5),
('Aurora', 16),
('Autumn', 7),
('Ava', 2),
('Avaeh', 1),
('Avalyn', 3),
('Avery', 1),
('Aviana', 4),
('Ayla', 1),
('Azalea', 3),
('Bailey', 6),
('Bella', 7),
('Belle', 6),
('Bentley', 6),
('Bianca', 9),
('Blake', 2),
('Bonnie', 6),
('Braelynn', 8),
('Brianna', 10),
('Bridget', 11),
('Brielle', 13),
('Brinley', 4),
('Bristol', 4),
('Brittany', 7),
('Brooke', 2),
('Brooklyn', 4),
('Brylee', 13),
('Brynlee', 6),
('Cadence', 6),
('Caitlin', 6),
('Cali', 7),
('Callie', 5),
('Camila', 8),
('Camille', 6),
('Candace', 3),
('Cara', 6),
('Carina', 8),
('Carissa', 7),
('Carla', 6),
('Carly', 7),
('Carmen', 2),
('Carol', 1),
('Caroline', 3),
('Carolyn', 4),
('Casey', 5),
('Cassandra', 8),
('Cassidy', 8),
('Catalina', 2),
('Catherine', 2),
('Caylee', 2),
('Cecilia', 12),
('Celeste', 6),
('Celia', 2),
('Chanel', 6),
('Charlee', 10),
('Charleigh', 3),
('Charley', 11),
('Charlie', 1),
('Charlize', 6),
('Charlotte', 8),
('Charmaine', 6),
('Chelsea', 4),
('Cheyenne', 2),
('Chloe', 13),
('Christina', 5),
('Christine', 6),
('Cindy', 5),
('Clara', 5),
('Claudia', 7),
('Clementine', 13),
('Colette', 1),
('Collins', 11),
('Cora', 6),
('Corinne', 11),
('Crystal', 5),
('Daisy', 5),
('Dakota', 8),
('Dana', 8),
('Daniela', 1),
('Daniella', 7),
('Danielle', 5),
('Danika', 8),
('Danna', 3),
('Daphne', 2),
('Darlene', 2),
('Davina', 8),
('Dayana', 5),
('Deanna', 7),
('Deborah', 5),
('Delaney', 4),
('Delilah', 4),
('Denise', 12),
('Desiree', 1),
('Destiny', 4),
('Diana', 4),
('Diane', 6),
('Dior', 12),
('Dixie', 3),
('Dolly', 1),
('Dominique', 7),
('Donna', 3),
('Dorothy', 8),
('Dream', 4),
('Dulce', 7),
('Ebony', 10),
('Eleanor', 7),
('Elizabeth', 11),
('Ella', 3),
('Emily', 7),
('Emma', 5),
('Evelyn', 5),
('Grace', 9),
('Harper', 7),
('Hazel', 1),
('Isabella', 3),
('Layla', 6),
('lea', 3),
('Luna', 6),
('Mia', 5),
('Nora', 1),
('Nova', 2),
('Olivia', 2),
('Penelope', 6),
('Riley', 5),
('Scarlett', 5),
('Sophia', 3),
('Victoria', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Train`
--
ALTER TABLE `Train`
  ADD PRIMARY KEY (`train_id`),
  ADD KEY `route_id` (`route_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Train`
--
ALTER TABLE `Train`
  ADD CONSTRAINT `Train_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `Route` (`route_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
